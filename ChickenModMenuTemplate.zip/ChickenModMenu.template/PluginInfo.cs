﻿namespace StupidTemplate
{
    public class PluginInfo
    {
        public const string GUID = "org.Hellcat.gorillatag.ChickenMenu";
        public const string Name = "Chicken Menu V1.0.5";
        public const string Description = "Mod Menu Made By HELLCATVR.";
        public const string Version = "1.0.5";
    }
}
