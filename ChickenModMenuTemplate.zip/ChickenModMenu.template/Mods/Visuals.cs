﻿using GorillaLocomotion;
using StupidTemplate.Classes;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.XR;
using static StupidTemplate.Menu.Main;

namespace StupidTemplate.Mods
{
    public class Visuals
    {
        public static void Nothing()
        {
            Debug.LogWarning("There Isn't No Visual Mods Yet!");
        }

        public static void XRay()
        {

        }
    }
}
