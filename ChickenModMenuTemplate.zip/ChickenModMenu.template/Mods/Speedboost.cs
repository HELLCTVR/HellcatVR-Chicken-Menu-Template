﻿using GorillaLocomotion;
using StupidTemplate.Classes;
using UnityEngine;
using UnityEngine.XR;
using static StupidTemplate.Menu.Main;

namespace StupidTemplate.Mods
{
    public class Speedboost
    {
        public static void SpeedboostNormal()
        {
            GorillaLocomotion.GTPlayer.Instance.maxJumpSpeed = 6f;
            GorillaLocomotion.GTPlayer.Instance.jumpMultiplier = 5f;
        }
        public static void SpeedboostFast()
        {
            GorillaLocomotion.GTPlayer.Instance.maxJumpSpeed = 8f;
            GorillaLocomotion.GTPlayer.Instance.jumpMultiplier = 7f;
        }
        public static void SpeedboostExtreme()
        {
            GorillaLocomotion.GTPlayer.Instance.maxJumpSpeed = 10f;
            GorillaLocomotion.GTPlayer.Instance.jumpMultiplier = 9f;
        }
        public static void BannedSpeedboost()
        {
            GorillaLocomotion.GTPlayer.Instance.maxJumpSpeed = 15f;
            GorillaLocomotion.GTPlayer.Instance.jumpMultiplier = 14f;
        }
        public static void FlyingSpeedboost()
        {
            GorillaLocomotion.GTPlayer.Instance.maxJumpSpeed = 100f;
            GorillaLocomotion.GTPlayer.Instance.jumpMultiplier = 99f;
        }
        public static void FlyingSpeedboost1()
        {
            GorillaLocomotion.GTPlayer.Instance.maxJumpSpeed = 500f;
            GorillaLocomotion.GTPlayer.Instance.jumpMultiplier = 499f;
        }
    }
}